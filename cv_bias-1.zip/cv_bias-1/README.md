# cv_bias

`cv_bias` is an experimental Python toolkit for studying how names and gender-coded
CV content affect language-model evaluations. It can:

- score every combination of a CV and participant name on five hiring criteria;
- sample rankings from randomized name-to-CV assignments;
- classify the perceived gender coding of CV text; and
- checkpoint long-running experiments so interrupted API runs can resume.

The repository is research code, not a hiring system. Model scores and gender-cue
labels are subjective outputs and should not be treated as ground truth or used to
make employment decisions.

## Repository layout

```text
cv_bias/
|-- data/                         # Local Excel inputs (ignored by Git)
|-- output/
|   |-- jupyter-notebook/         # Experiment and smoke-test notebooks
|   `-- experiment-results_*/     # Checkpoints and exported results
|-- src/
|   |-- cv_evaluation_pipeline.py # Scoring and ranking orchestration
|   |-- gender_cv_pipeline.py     # Gender-cue classification
|   |-- cv_improvement_pipeline.py# Reserved; currently empty
|   |-- language_models/          # Provider adapters and output validation
|   `-- utils/                    # CV text helpers
|-- tests/                        # Unit tests
`-- requirements.txt
```

## Setup

Python 3.10 or newer is required. The current development environment uses Python
3.12.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

The requirements file supports the core pipeline and OpenAI adapter. Install only
the extra providers and notebook tools you plan to use:

```bash
python -m pip install anthropic google-genai mistralai python-dotenv jupyter
```

The project is not packaged, so commands and notebooks add `src/` to Python's import
path. For scripts or an interactive shell, run:

```bash
export PYTHONPATH="$PWD/src"
```

Provider adapters read API keys from the environment:

```bash
export OPENAI_API_KEY="..."
export GOOGLE_API_KEY="..."
export ANTHROPIC_API_KEY="..."
export MISTRAL_API_KEY="..."
```

You may instead place these values in a local `.env` file when using the notebooks.
Both `.env` and `data/` are ignored by Git. Never commit API keys or sensitive CV
data.

## Quick start: score CVs

Each CV template may contain `$$NAME$$`. The scoring pipeline substitutes every
provided name into every CV, calls each configured model, and writes one name-by-CV
CSV matrix per model and scoring dimension.

```python
from cv_evaluation_pipeline import ScoringPipeline
from language_models.openai import OpenAILLM

SCORER_PROMPT = """Evaluate this CV. Return only a JSON object with integer scores
from 1 to 5 for exactly these keys: "Relevance to the Role",
"Significance/Impact", "Skill Relevance", "Achievements & Impact", and
"Cultural Fit & Personal Traits".

<<CV>>
"""

model = OpenAILLM(
    model_name="gpt-5.6-luna",
    instruction_prompt_scorer=SCORER_PROMPT,
    instruction_prompt_scorer_retry="Return only the required JSON object.",
)

pipeline = ScoringPipeline([model])
scores = pipeline.score_all(
    cv_texts=[
        "Candidate: $$NAME$$\nPython developer with five years of experience.",
        "Candidate: $$NAME$$\nData analyst experienced with SQL and dashboards.",
    ],
    names=["Alex", "Sam"],
    cv_identifiers=["cv-001", "cv-002"],
    write_path="output/demo/scores.csv",
)
```

The return value is nested as `scores[model_name][dimension]`. With one model, the
example creates files such as:

```text
output/demo/scores_relevance_to_the_role.csv
output/demo/scores_significance_impact.csv
output/demo/scores_skill_relevance.csv
output/demo/scores_achievements_impact.csv
output/demo/scores_cultural_fit_personal_traits.csv
```

With multiple models, the model name is also included in each filename. Existing
matrices are loaded and only missing cells are evaluated. Keep names, CV identifiers,
and dimensions stable when resuming from an existing checkpoint.

## Quick start: sample rankings

Ranking selects distinct CVs for the supplied names, randomizes presentation order,
and asks each model to return the CV identifiers in rank order. There must be at
least as many CVs as names.

```python
RANKER_PROMPT = """Rank the CVs from strongest to weakest. Return only a JSON
object whose keys are rank strings ("1", "2", and so on) and whose values are the
provided CV identifiers. Use each identifier exactly once.

<<CVS>>
"""

model.instruction_prompt_ranker = RANKER_PROMPT

rankings = pipeline.sample_rankings(
    cv_texts=["CV A for $$NAME$$", "CV B for $$NAME$$"],
    names=["Alex", "Sam"],
    num_samples=2,
    cv_identifiers=["cv-a", "cv-b"],
    seed=4,
    write_path="output/demo/rankings.csv",
)
```

Each output row contains the model name followed by tuples of
`(participant name, CV identifier, numeric rank)`. Reusing the same output path skips
the number of samples already recorded for each model. `num_samples` cannot exceed
the number of unique ordered CV selections, `math.perm(number_of_cvs,
number_of_names)`.

## Quick start: classify gender coding

`GenderCVPipeline` accepts either a DataFrame or an Excel worksheet. By default the
input must contain:

- `cv_id`: unique and non-null; used to match checkpoint rows;
- `cv_text`: a non-null string containing the CV; and
- no existing `predicted_gender` column.

```python
from gender_cv_pipeline import GenderCVPipeline
from language_models.openai import OpenAILLM

GENDER_PROMPT = """Classify only the gender-coded presentation of this CV.
Return exactly one label: masculine_coded, feminine_coded, or
no_clear_gender_cue.

<<CV>>
"""

model = OpenAILLM(
    model_name="gpt-5.6-luna",
    instruction_prompt_scorer="unused by gender classification",
)
pipeline = GenderCVPipeline(
    model,
    gender_prompt=GENDER_PROMPT,
    retry_prompt="Return exactly one allowed label and no other text.",
)

result = pipeline.classify_excel(
    "data/my_cvs.xlsx",
    sheet_name="test_cvs",
    checkpoint_path="output/demo/gender_predictions.csv",
)
result.to_excel("output/demo/gender_predictions.xlsx", index=False)
```

The CSV checkpoint contains only `cv_id` and `predicted_gender`. It is saved after
each successful row and resumes by `cv_id`, even if the input rows are reordered.
Invalid model responses are retried up to the model's `call_budget` (three calls by
default). Rows that still fail remain missing, processing continues, and their input
indices are available in `pipeline.failed_indices`.

Column names can be changed with the `id_column`, `cv_column`, and `output_column`
arguments. A checkpoint must contain the same set of CV IDs as its input.

## Notebooks

Start Jupyter from the repository root:

```bash
source .venv/bin/activate
jupyter notebook output/jupyter-notebook
```

The included notebooks serve different purposes:

- `pipeline-smoke-test.ipynb` exercises scoring, ranking, schema validation, retries,
  and checkpoints with a deterministic offline model. Its optional OpenAI section
  runs when `OPENAI_API_KEY` is available.
- `data_analysis.ipynb` runs the main original-versus-enhanced CV scoring experiment
  against `data/thesis_test_V3.xlsx`. It resolves CV and vacancy tables, scores each
  row on all five dimensions, and writes separate resume-safe CSVs.
- `cv-gender-classification.ipynb` runs an offline preflight and then classifies the
  `cv_id`/`cv_text` rows in `data/thesis_test_V4.xlsx` across a selected provider.

Review each notebook's configuration cell before running it. Some checked-in cells
currently set live execution to `True`; live runs incur provider charges and send CV
content to external APIs. Output directories and filenames are controlled in those
same cells.

The main experiment workbook expects these sheets:

| Sheet | Required content |
| --- | --- |
| `test_vacancies` | `vacancy_id`, `vacancy_html_code` |
| `test_cvs` | `cv_id`, `cv_html_code` |
| `test_original` | experiment metadata, `name`, and a `cv_id` reference |
| `test_enhanced` | experiment metadata, `name`, and `cv_html_code` |

## How the code works

`BaseLanguageModel` defines the provider-independent contracts. Provider adapters
implement only `run(prompt, instructions)`, while the base class performs prompt
substitution, parses the first JSON object in a response, validates it with JSON
Schema, and retries malformed outputs.

`ScoringPipeline` builds the cross-product of models, CVs, and names. For scoring it
stores a matrix for each rubric dimension and writes after every completed call. For
ranking it samples unique name-to-CV maps, delegates response validation to the base
model, converts the returned identifier order to numeric ranks, and appends each run
to a CSV.

`GenderCVPipeline` validates the complete input before making any model call. It then
loads compatible predictions from a checkpoint, calls the model for missing rows,
and persists each valid label immediately. A legacy text-based checkpoint format is
also migrated when its row order and CV text still match.

The concrete adapters are:

| Adapter | Environment variable | API used |
| --- | --- | --- |
| `OpenAILLM` | `OPENAI_API_KEY` | OpenAI Responses API |
| `GoogleLLM` | `GOOGLE_API_KEY` | Google Gen AI interactions |
| `AnthropicLLM` | `ANTHROPIC_API_KEY` | Anthropic Messages API |
| `MistralLLM` | `MISTRAL_API_KEY` | Mistral chat completion API |

The Mistral adapter currently waits five seconds before each call. Model IDs are not
hard-coded in the adapters; pass an ID supported by your provider account.