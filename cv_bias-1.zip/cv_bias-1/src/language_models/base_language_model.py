from abc import ABC, abstractmethod
import json
import logging
from collections.abc import Callable
from typing import TypeVar

from jsonschema import Draft202012Validator, ValidationError


T = TypeVar("T")
logger = logging.getLogger(__name__)
MODEL_OUTPUT_ERRORS = (
    json.JSONDecodeError,
    ValidationError,
    ValueError,
    KeyError,
    TypeError,
)


def ranking_schema(num_cvs: int) -> dict:
    ranks = [str(rank) for rank in range(1, num_cvs + 1)]
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {rank: {"type": "string"} for rank in ranks},
        "required": ranks,
        "additionalProperties": False,
    }


RANKING_SCHEMA = ranking_schema(6)
SCORING_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "properties": {
        "Relevance to the Role": {"$ref": "#/$defs/resumeScore"},
        "Significance/Impact": {"$ref": "#/$defs/resumeScore"},
        "Skill Relevance": {"$ref": "#/$defs/resumeScore"},
        "Achievements & Impact": {"$ref": "#/$defs/resumeScore"},
        "Cultural Fit & Personal Traits": {"$ref": "#/$defs/resumeScore"},
    },
    "required": [
        "Relevance to the Role",
        "Significance/Impact",
        "Skill Relevance",
        "Achievements & Impact",
        "Cultural Fit & Personal Traits",
    ],
    "additionalProperties": False,
    "$defs": {
        "resumeScore": {
            "type": "integer",
            "minimum": 1,
            "maximum": 5,
        },
    },
}
SCORING_DIMENSIONS = tuple(SCORING_SCHEMA["required"])
GENDER_LABELS = ("masculine_coded", "feminine_coded", "no_clear_gender_cue")


def extract_first_json_object(output: str) -> dict:
    """Return the first valid JSON object embedded in model output."""
    decoder = json.JSONDecoder()
    search_from = 0
    last_error: json.JSONDecodeError | None = None

    while (object_start := output.find("{", search_from)) != -1:
        try:
            value, _ = decoder.raw_decode(output, object_start)
        except json.JSONDecodeError as error:
            last_error = error
        else:
            if isinstance(value, dict):
                return value
        search_from = object_start + 1

    if last_error is not None:
        raise last_error
    raise json.JSONDecodeError("No JSON object found", output, 0)


class BaseLanguageModel(ABC):
    """Base class for language models"""

    def __init__(
        self,
        model_name: str,
        instruction_prompt_scorer: str,
        instruction_prompt_ranker: str | None = None,
        call_budget: int = 3,
        instruction_prompt_scorer_retry: str | None = None,
    ):
        self.model_name = model_name
        self.instruction_prompt_scorer = instruction_prompt_scorer
        self.instruction_prompt_ranker = instruction_prompt_ranker
        self.call_budget = call_budget
        self.instruction_prompt_scorer_retry = instruction_prompt_scorer_retry
        self.total_reruns = 0
        self.total_failures = 0

    @abstractmethod
    def run(self, prompt: str, instructions: str | None = None) -> str:
        """Run one provider-specific model call and return its text output."""

    def score_cv(self, cv_text: str, prompt_template: str) -> dict[str, float]:
        """Run, validate, and return the individual criterion scores."""
        prompt = prompt_template.replace("<<CV>>", cv_text)
        retry_instructions = self.instruction_prompt_scorer_retry

        def rerun_score() -> str:
            return self.run(
                prompt,
                instructions=retry_instructions,
            )

        scores = self._run_and_fetch(
            lambda: self.run(prompt),
            self._validate_and_fetch_scorer_output,
            "scoring",
            retry_run=rerun_score if retry_instructions is not None else None,
        )
        return scores

    def rank_cvs(
        self,
        cv_texts: list[str],
        prompt_template: str,
        cv_identifiers: list[str] | None = None,
    ) -> list[str]:
        """Run, validate, and return CV identifiers in rank order."""
        cv_ids = list(map(str, cv_identifiers or range(len(cv_texts))))
        labeled_cvs = [
            f"CV identifier: {cv_id}\n{cv_text}"
            for cv_id, cv_text in zip(cv_ids, cv_texts, strict=True)
        ]
        prompt = prompt_template.replace("<<CVS>>", "\n\n".join(labeled_cvs))
        return self._run_and_fetch(
            lambda: self.run(prompt),
            lambda output: self._validate_and_fetch_ranker_output(
                output, len(cv_texts), cv_ids
            ),
            "ranking",
        )

    def classify_cv_gender(
        self,
        cv_text: str,
        prompt_template: str,
        retry_prompt: str | None = None,
    ) -> str:
        """Classify a CV using the strict binary gender response contract."""
        if "<<CV>>" not in prompt_template:
            raise ValueError("gender prompt must contain the <<CV>> delimiter")

        prompt = prompt_template.replace("<<CV>>", cv_text)

        def rerun_gender_classification() -> str:
            return self.run(prompt, instructions=retry_prompt)

        return self._run_and_fetch(
            lambda: self.run(prompt),
            self._validate_and_fetch_gender_output,
            "gender classification",
            retry_run=(
                rerun_gender_classification if retry_prompt is not None else None
            ),
        )

    def _validate_and_fetch_scorer_output(self, output: str) -> dict[str, float]:
        """Validate and extract criterion scores."""
        scores = extract_first_json_object(output)
        Draft202012Validator(SCORING_SCHEMA).validate(scores)
        return {criterion: float(score) for criterion, score in scores.items()}

    def _validate_and_fetch_ranker_output(
        self,
        output: str,
        num_cvs: int,
        expected_identifiers: list[str] | None = None,
    ) -> list[str]:
        """Validate and extract CV identifiers in rank order."""
        ranks = extract_first_json_object(output)
        Draft202012Validator(ranking_schema(num_cvs)).validate(ranks)
        ordered = [ranks[str(rank)] for rank in range(1, num_cvs + 1)]
        if expected_identifiers is not None and set(ordered) != set(
            expected_identifiers
        ):
            raise ValueError("ranking did not contain each CV identifier exactly once")
        return ordered

    def _validate_and_fetch_gender_output(self, output: str) -> str:
        """Return a gender label only when the response matches the contract."""
        prediction = output.strip()
        if prediction not in GENDER_LABELS:
            raise ValueError(
                "gender classification must be exactly one of the allowed labels"
            )
        return prediction

    def _run_and_fetch(
        self,
        run: Callable[[], str],
        fetch: Callable[[str], T],
        task: str,
        retry_run: Callable[[], str] | None = None,
    ) -> T:
        reruns = 0
        try:
            output = run()
            while True:
                try:
                    return fetch(output)
                except MODEL_OUTPUT_ERRORS:
                    if reruns >= self.call_budget - 1:
                        raise
                    reruns += 1
                    output = (retry_run or run)()
        finally:
            self.total_reruns += reruns
            if reruns:
                logger.warning(
                    "%s reran the %s prompt %d time(s)",
                    self.model_name,
                    task,
                    reruns,
                )
