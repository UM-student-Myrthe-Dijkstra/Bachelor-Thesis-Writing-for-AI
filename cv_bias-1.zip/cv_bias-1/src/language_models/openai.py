import os
from typing import Optional
from openai import Omit, OpenAI
from language_models.base_language_model import BaseLanguageModel


class OpenAILLM(BaseLanguageModel):
    def __init__(
        self, model_name: str, api_key: Optional[str] = None, **kwargs
    ) -> None:
        super().__init__(model_name, **kwargs)
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.openai_client = OpenAI(
            api_key=self.api_key if self.api_key else os.environ.get("OPENAI_API_KEY")
        )
        if not self.api_key:
            raise ValueError(
                "OpenAI API key must be provided or set in the environment."
            )

    def run(self, prompt: str, instructions: str | None = None) -> str:
        return self.openai_client.responses.create(
            model=self.model_name,
            input=prompt,
            instructions=instructions,
        ).output_text
