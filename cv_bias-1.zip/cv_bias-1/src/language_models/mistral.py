import os
import time
from typing import Optional
from language_models.base_language_model import BaseLanguageModel
from mistralai.client import Mistral


class MistralLLM(BaseLanguageModel):
    def __init__(
        self, model_name: str, api_key: Optional[str] = None, **kwargs
    ) -> None:
        super().__init__(model_name, **kwargs)
        self.api_key = api_key or os.getenv("MISTRAL_API_KEY")
        self.client = Mistral(api_key=self.api_key)
        self.model_name = model_name
        if not self.api_key:
            raise ValueError(
                "mistral API key must be provided or set in the environment."
            )

    def run(self, prompt: str, instructions: str | None = None) -> str:
        messages = []
        time.sleep(5)
        if instructions is not None:
            messages.append({"role": "user", "content": instructions})
        messages.append({"role": "user", "content": prompt})
        response = (
            self.client.chat.complete(
                model=self.model_name,
                messages=messages,
            )
            .choices[0]
            .message.content
        )
        return response
