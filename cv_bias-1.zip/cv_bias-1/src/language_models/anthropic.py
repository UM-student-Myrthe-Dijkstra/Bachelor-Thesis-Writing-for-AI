import os
from typing import Optional
from language_models.base_language_model import BaseLanguageModel
from anthropic import Anthropic


class AnthropicLLM(BaseLanguageModel):
    def __init__(
        self, model_name: str, api_key: Optional[str] = None, **kwargs
    ) -> None:
        super().__init__(model_name, **kwargs)
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.client = Anthropic(api_key=self.api_key)
        self.max_tokens = kwargs.get("max_tokens", 1024)
        self.model_name = model_name
        if not self.api_key:
            raise ValueError(
                "Anthropic API key must be provided or set in the environment."
            )

    def run(self, prompt: str, instructions: str | None = None) -> str:
        messages = []
        if instructions is not None:
            messages.append({"role": "user", "content": instructions})
        messages.append({"role": "user", "content": prompt})
        response = (
            self.client.messages.create(
                max_tokens=self.max_tokens,
                model=self.model_name,
                messages=messages,
            )
            .content[0]
            .text
        )
        return response
