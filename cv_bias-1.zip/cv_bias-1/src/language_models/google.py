import os
from typing import Optional
from language_models.base_language_model import BaseLanguageModel
from google import genai


class GoogleLLM(BaseLanguageModel):
    def __init__(
        self, model_name: str, api_key: Optional[str] = None, **kwargs
    ) -> None:
        super().__init__(model_name, **kwargs)
        self.api_key = api_key or os.getenv("GOOGLE_API_KEY")
        self.google_client = genai.Client(
            api_key=self.api_key if self.api_key else os.environ.get("GOOGLE_API_KEY")
        )
        self.model_name = model_name
        if not self.api_key:
            raise ValueError(
                "Google API key must be provided or set in the environment."
            )

    def run(self, prompt: str, instructions: str | None = None) -> str:
        return self.google_client.interactions.create(
            model=self.model_name,
            input=prompt,
            system_instruction=instructions,
        ).output_text
