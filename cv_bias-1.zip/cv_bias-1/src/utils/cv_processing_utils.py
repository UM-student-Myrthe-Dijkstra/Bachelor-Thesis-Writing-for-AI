import ftfy


def add_name_to_cv(cv_text: str, name: str, name_delimiter: str = "$$NAME$$") -> str:
    """
    Adds a name to a CV text at the specified delimiter.

    Args:
        cv_text (str): The original CV text.
        name (str): The name to be added to the CV.
        name_delimiter (str): The placeholder in the CV text where the name should be inserted.

    Returns:
        str: The CV text with the name added.
    """
    return cv_text.replace(name_delimiter, name)


def clean_mojibake(cv_text: str) -> tuple[str, bool]:
    """
    Cleans mojibake (garbled text) from a CV text.

    Args:
        cv_text (str): The original CV text.
    """
    fixed = ftfy.fix_text(cv_text)
    is_mojibake = fixed != cv_text
    return fixed, is_mojibake
