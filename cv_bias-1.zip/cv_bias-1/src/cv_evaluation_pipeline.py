from __future__ import annotations

import ast
import math
import random
import re
from pathlib import Path

import pandas as pd
from tqdm.auto import tqdm

from language_models.base_language_model import BaseLanguageModel, SCORING_DIMENSIONS
from utils.cv_processing_utils import add_name_to_cv


def _model_path(path: str | Path, model: str, multiple_models: bool) -> Path:
    path = Path(path).with_suffix(".csv")
    if multiple_models:
        path = path.with_name(f"{path.stem}_{model}.csv")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _score_path(
    path: str | Path, model: str, dimension: str, multiple_models: bool
) -> Path:
    path = Path(path).with_suffix(".csv")
    labels = [path.stem, *((model,) if multiple_models else ()), dimension]
    filename = "_".join(
        re.sub(r"\W+", "_", label).strip("_").lower() for label in labels
    )
    path = path.with_name(f"{filename}.csv")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


class ScoringPipeline:
    """Pipeline for letting LLMs evaluate CVs."""

    def __init__(self, llms: list[BaseLanguageModel]):
        self.llms = llms

    def score_all(
        self,
        cv_texts: list[str],
        names: list[str],
        *,
        cv_identifiers: list[str] | None = None,
        write_path: str | Path = "scores.csv",
        show_progress: bool = True,
        scoring_dimensions: list[str] | None = None,
    ) -> dict[str, dict[str, pd.DataFrame]]:
        """Checkpoint one name-by-CV score matrix per model and dimension."""
        self._validate_common_inputs(cv_texts, names)
        cv_ids = list(map(str, cv_identifiers or range(len(cv_texts))))
        dimensions = scoring_dimensions or list(SCORING_DIMENSIONS)
        multiple_models = len(self.llms) > 1
        results: dict[str, dict[str, pd.DataFrame]] = {}

        for llm in self.llms:
            results[llm.model_name] = {}
            for dimension in dimensions:
                path = _score_path(
                    write_path, llm.model_name, dimension, multiple_models
                )
                if path.exists():
                    scores = pd.read_csv(path, index_col=0).reindex(
                        index=names, columns=cv_ids
                    )
                else:
                    scores = pd.DataFrame(index=names, columns=cv_ids, dtype="Float64")
                    scores.index.name = "Participant Name"
                    scores.to_csv(path)
                results[llm.model_name][dimension] = scores

        jobs = [
            (llm, name_index, cv_index)
            for llm in self.llms
            for cv_index in range(len(cv_texts))
            for name_index in range(len(names))
            if any(
                pd.isna(results[llm.model_name][dimension].iat[name_index, cv_index])
                for dimension in dimensions
            )
        ]
        for llm, name_index, cv_index in tqdm(
            jobs,
            desc="Scoring CVs",
            disable=not show_progress,
            unit="score",
        ):
            score_dict = llm.score_cv(
                add_name_to_cv(cv_texts[cv_index], names[name_index]),
                llm.instruction_prompt_scorer,
            )
            for dimension in dimensions:
                scores = results[llm.model_name][dimension]
                scores.iat[name_index, cv_index] = score_dict[dimension]
                scores.to_csv(
                    _score_path(
                        write_path, llm.model_name, dimension, multiple_models
                    )
                )

        return results

    def sample_rankings(
        self,
        cv_texts: list[str],
        names: list[str],
        num_samples: int,
        *,
        cv_identifiers: list[str] | None = None,
        seed: int | None = None,
        write_path: str | Path = "rankings.csv",
        show_progress: bool = True,
    ) -> pd.DataFrame:
        """Store each sampled ranking as one row of participant/CV/rank tuples."""
        self._validate_common_inputs(cv_texts, names)
        if len(cv_texts) < len(names):
            raise ValueError("sample_rankings requires at least as many CVs as names")
        if num_samples > math.perm(len(cv_texts), len(names)):
            raise ValueError("num_samples exceeds the number of unique name-CV maps")

        cv_ids = list(map(str, cv_identifiers or range(len(cv_texts))))
        columns = ["Model", *[f"Participant {i + 1}" for i in range(len(names))]]
        path = _model_path(write_path, "", False)
        converters = {column: ast.literal_eval for column in columns[1:]}
        results = (
            pd.read_csv(path, converters=converters)
            if path.exists()
            else pd.DataFrame(columns=columns)
        )
        completed = results["Model"].value_counts().to_dict()
        if not path.exists():
            results.to_csv(path, index=False)

        rng = random.Random(seed)
        jobs = sum(
            num_samples - min(completed.get(llm.model_name, 0), num_samples)
            for llm in self.llms
        )
        with tqdm(
            total=jobs,
            desc="Sampling rankings",
            disable=not show_progress,
            unit="ranking",
        ) as progress:
            seen_maps: set[tuple[int, ...]] = set()
            for sample_index in range(num_samples):
                while True:
                    selected = tuple(rng.sample(range(len(cv_texts)), len(names)))
                    if selected not in seen_maps:
                        seen_maps.add(selected)
                        break
                assignments = list(zip(selected, names, strict=True))
                rng.shuffle(assignments)
                named_cvs = [
                    add_name_to_cv(cv_texts[cv_index], name)
                    for cv_index, name in assignments
                ]

                for llm in self.llms:
                    if sample_index < completed.get(llm.model_name, 0):
                        continue
                    presented_ids = [cv_ids[cv_index] for cv_index, _ in assignments]
                    ranking = llm.rank_cvs(
                        named_cvs,
                        llm.instruction_prompt_ranker,
                        presented_ids,
                    )
                    rank_by_id = {
                        cv_identifier: rank
                        for rank, cv_identifier in enumerate(ranking, start=1)
                    }
                    update = pd.DataFrame(
                        [
                            [
                                llm.model_name,
                                *(
                                    (
                                        name,
                                        cv_ids[cv_index],
                                        rank_by_id[cv_ids[cv_index]],
                                    )
                                    for cv_index, name in assignments
                                ),
                            ]
                        ],
                        columns=columns,
                    )
                    results = (
                        update
                        if results.empty
                        else pd.concat([results, update], ignore_index=True)
                    )
                    results.to_csv(path, index=False)
                    progress.update()

        return results

    def _validate_common_inputs(self, cv_texts: list[str], names: list[str]) -> None:
        if not cv_texts:
            raise ValueError("cv_texts must not be empty")
        if not names:
            raise ValueError("names must not be empty")
