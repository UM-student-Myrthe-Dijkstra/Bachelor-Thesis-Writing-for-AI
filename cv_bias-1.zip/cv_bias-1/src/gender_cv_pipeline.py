from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pandas as pd
from tqdm.auto import tqdm

from language_models.base_language_model import (
    GENDER_LABELS,
    MODEL_OUTPUT_ERRORS,
    BaseLanguageModel,
)


logger = logging.getLogger(__name__)
LEGACY_CHECKPOINT_ROW_COLUMN = "__row_position"


class GenderCVPipeline:
    """Classify the perceived binary gender in each CV of a DataFrame."""

    def __init__(
        self,
        llm: BaseLanguageModel,
        gender_prompt: str,
        retry_prompt: str,
    ) -> None:
        if "<<CV>>" not in gender_prompt:
            raise ValueError("gender_prompt must contain the <<CV>> delimiter")
        self.llm = llm
        self.gender_prompt = gender_prompt
        self.retry_prompt = retry_prompt
        self.failed_indices: list[object] = []

    def classify_excel(
        self,
        workbook_path: str | Path,
        *,
        sheet_name: str | int = 0,
        id_column: str = "cv_id",
        cv_column: str = "cv_text",
        output_column: str = "predicted_gender",
        checkpoint_path: str | Path | None = None,
        show_progress: bool = True,
        read_excel_kwargs: dict[str, Any] | None = None,
    ) -> pd.DataFrame:
        """Load an Excel worksheet and classify every CV row."""
        frame = pd.read_excel(
            workbook_path,
            sheet_name=sheet_name,
            **(read_excel_kwargs or {}),
        )
        return self.classify_dataframe(
            frame,
            id_column=id_column,
            cv_column=cv_column,
            output_column=output_column,
            checkpoint_path=checkpoint_path,
            show_progress=show_progress,
        )

    def classify_dataframe(
        self,
        frame: pd.DataFrame,
        *,
        id_column: str = "cv_id",
        cv_column: str = "cv_text",
        output_column: str = "predicted_gender",
        checkpoint_path: str | Path | None = None,
        show_progress: bool = True,
    ) -> pd.DataFrame:
        """Return a copy of ``frame`` with one prediction per valid response."""
        self._validate_frame(frame, id_column, cv_column, output_column)
        result = frame.copy(deep=True)
        predictions = [pd.NA] * len(result)
        checkpoint = Path(checkpoint_path) if checkpoint_path is not None else None

        if checkpoint is not None and checkpoint.exists():
            predictions = self._load_checkpoint(
                checkpoint,
                frame,
                id_column=id_column,
                cv_column=cv_column,
                output_column=output_column,
            )

        result[output_column] = pd.array(predictions, dtype="string")
        if checkpoint is not None and checkpoint.exists():
            self._save_checkpoint(
                checkpoint,
                result,
                id_column=id_column,
                output_column=output_column,
            )
        self.failed_indices = []

        pending_positions = [
            position
            for position, prediction in enumerate(predictions)
            if pd.isna(prediction)
        ]
        for position in tqdm(
            pending_positions,
            desc="Classifying CV gender",
            disable=not show_progress,
            unit="CV",
        ):
            cv_text = frame.iloc[position][cv_column]
            try:
                prediction = self.llm.classify_cv_gender(
                    cv_text,
                    self.gender_prompt,
                    self.retry_prompt,
                )
            except MODEL_OUTPUT_ERRORS as error:
                row_index = frame.index[position]
                self.failed_indices.append(row_index)
                logger.warning(
                    "Gender classification failed for row index %r after %d attempt(s): %s",
                    row_index,
                    self.llm.call_budget,
                    error,
                )
                continue

            result.iat[position, result.columns.get_loc(output_column)] = prediction
            if checkpoint is not None:
                self._save_checkpoint(
                    checkpoint,
                    result,
                    id_column=id_column,
                    output_column=output_column,
                )

        return result

    @staticmethod
    def _validate_frame(
        frame: pd.DataFrame,
        id_column: str,
        cv_column: str,
        output_column: str,
    ) -> None:
        if cv_column not in frame.columns:
            raise ValueError(f"input DataFrame must contain a {cv_column!r} column")
        if id_column not in frame.columns:
            raise ValueError(f"input DataFrame must contain a {id_column!r} column")
        if output_column in frame.columns:
            raise ValueError(
                f"input DataFrame already contains output column {output_column!r}"
            )

        invalid = frame[cv_column].map(lambda value: not isinstance(value, str))
        if invalid.any():
            indices = frame.index[invalid].tolist()
            raise ValueError(
                f"{cv_column!r} must contain only non-null strings; "
                f"invalid row indices: {indices}"
            )

        if frame[id_column].isna().any():
            indices = frame.index[frame[id_column].isna()].tolist()
            raise ValueError(
                f"{id_column!r} must contain only non-null values; "
                f"invalid row indices: {indices}"
            )
        serialized_ids = frame[id_column].map(str)
        if serialized_ids.eq("").any():
            indices = frame.index[serialized_ids.eq("")].tolist()
            raise ValueError(
                f"{id_column!r} must contain non-empty values; "
                f"invalid row indices: {indices}"
            )
        if serialized_ids.duplicated().any():
            duplicate_ids = serialized_ids[serialized_ids.duplicated(False)].unique()
            raise ValueError(
                f"{id_column!r} must contain unique values; "
                f"duplicates: {duplicate_ids.tolist()}"
            )

    @staticmethod
    def _load_checkpoint(
        path: Path,
        frame: pd.DataFrame,
        *,
        id_column: str,
        cv_column: str,
        output_column: str,
    ) -> list[object]:
        checkpoint = pd.read_csv(path, dtype=str, keep_default_na=False)
        required_columns = [id_column, output_column]
        legacy_columns = [
            LEGACY_CHECKPOINT_ROW_COLUMN,
            cv_column,
            output_column,
        ]
        checkpoint_columns = checkpoint.columns.tolist()
        if checkpoint_columns not in (required_columns, legacy_columns):
            raise ValueError(
                f"checkpoint {path} must contain exactly {required_columns}"
            )
        if len(checkpoint) != len(frame):
            raise ValueError(f"checkpoint {path} does not match the input row count")

        predictions = checkpoint[output_column].tolist()
        invalid_predictions = [
            prediction
            for prediction in predictions
            if prediction and prediction not in GENDER_LABELS
        ]
        if invalid_predictions:
            raise ValueError(f"checkpoint {path} contains invalid predictions")

        if checkpoint_columns == legacy_columns:
            try:
                positions = checkpoint[LEGACY_CHECKPOINT_ROW_COLUMN].astype(int)
            except ValueError as error:
                raise ValueError(
                    f"legacy checkpoint {path} has invalid row positions"
                ) from error
            if positions.tolist() != list(range(len(frame))):
                raise ValueError(
                    f"legacy checkpoint {path} has reordered or invalid rows"
                )
            if checkpoint[cv_column].tolist() != frame[cv_column].tolist():
                raise ValueError(
                    f"legacy checkpoint {path} does not match the input CV text"
                )
            return [prediction or pd.NA for prediction in predictions]

        checkpoint_ids = checkpoint[id_column]
        if checkpoint_ids.eq("").any() or checkpoint_ids.duplicated().any():
            raise ValueError(f"checkpoint {path} contains invalid CV IDs")
        input_ids = frame[id_column].map(str).tolist()
        if set(checkpoint_ids) != set(input_ids):
            raise ValueError(f"checkpoint {path} does not match the input CV IDs")
        predictions_by_id = dict(zip(checkpoint_ids, predictions, strict=True))
        return [predictions_by_id[cv_id] or pd.NA for cv_id in input_ids]

    @staticmethod
    def _save_checkpoint(
        path: Path,
        result: pd.DataFrame,
        *,
        id_column: str,
        output_column: str,
    ) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        checkpoint = pd.DataFrame(
            {
                id_column: result[id_column].tolist(),
                output_column: result[output_column].fillna("").tolist(),
            }
        )
        temporary_path = path.with_name(f".{path.name}.tmp")
        checkpoint.to_csv(temporary_path, index=False)
        temporary_path.replace(path)
